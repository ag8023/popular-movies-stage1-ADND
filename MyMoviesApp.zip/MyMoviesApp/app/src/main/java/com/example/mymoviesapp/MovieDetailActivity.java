package com.example.mymoviesapp;
//Step 8
import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

public class MovieDetailActivity extends AppCompatActivity {

    private ImageView m_img;
    private TextView m_title;
    private TextView m_vote;
    private TextView m_date;
    private TextView m_desc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_detail);
        Bundle bundle=getIntent().getExtras();
     String title =bundle.getString("title");
      String overview=bundle.getString("overview");
      String vote=bundle.getString("vote");
      String releaseDate=bundle.getString("releaseDate");
      String poster=bundle.getString("poster");

      m_img=(ImageView)findViewById(R.id.movieImage);
      m_title=(TextView)findViewById(R.id.movieTitle);
      m_vote=(TextView)findViewById(R.id.vote);
      m_date=(TextView)findViewById(R.id.releaseDate);
      m_desc=(TextView)findViewById(R.id.overview);
        Picasso.get().load(poster).into(m_img);
        m_title.setText(title);
        m_vote.setText(vote);
        m_date.setText(releaseDate);
        m_desc.setText(overview);
     //   SharedPreferences sharedPref=getSharedPreferences("MovieDetail", MODE_PRIVATE);

      // String test= sharedPref.getString("title","no define");
       //Toast.makeText(this, test, Toast.LENGTH_LONG).show();




    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
