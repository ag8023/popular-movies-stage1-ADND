package com.example.mymoviesapp;
//Step 5
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RerofitClientInstance {
    public static Retrofit retrofit;

    public static Retrofit getRetrofit() {
        if(retrofit==null){
            retrofit=new Retrofit.Builder().baseUrl("http://api.themoviedb.org/3/movie/").addConverterFactory(GsonConverterFactory.create()).build(); // build the url string
        }
        return retrofit;
    }
    public static  ApiInterface getApiCLient(){
        return  getRetrofit().create(ApiInterface.class);
    }

}
