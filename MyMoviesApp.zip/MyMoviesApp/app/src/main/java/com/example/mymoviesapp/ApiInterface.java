package com.example.mymoviesapp;
//Step 4
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiInterface {


    @GET("popular") // API endpoints to use for this phase
    Call<ResponseJSON> getPopular(@Query ("api_key") String api_key); // creating objects of ResponseJSON to later fetch more data from these objects

    @GET("top_rated") // API endpoints to use for this phase
    Call<ResponseJSON> getToprated(@Query ("api_key") String api_key);
}