package com.example.mymoviesapp;
//Step 2
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ResponseJSON {
    @SerializedName("total_result")
    String total_result;

    public String getTotal_result() {
        return total_result;
    }

    public void setTotal_result(String total_result) {
        this.total_result = total_result;
    }

    public List<ResultList> getResultList() {
        return resultList;
    }

    public void setResultList(List<ResultList> resultList) {
        this.resultList = resultList;
    }

    @SerializedName("results") // using this annotation to compare with the actual JSON data and collect the results array from the entire json data
    List<ResultList> resultList;





}
