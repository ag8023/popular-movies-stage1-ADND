package com.example.mymoviesapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class ViewTrailer extends AppCompatActivity {
    private WebView wbv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_trailer);
        wbv=(WebView)findViewById(R.id.mv_trailer);
        wbv.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        wbv.getSettings().setLoadsImagesAutomatically(true
        );
        wbv.loadUrl("");
    }
}
