package com.example.mymoviesapp;
//Step 7
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class GridAdapter extends BaseAdapter {
    Context context;
    List<ResultList> resultLists;
    public GridAdapter(Context ctx,List<ResultList> mResultList){
        context=ctx;
        resultLists=mResultList;
    }

    @Override
    public int getCount() {
        return resultLists.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {
        view= LayoutInflater.from(context).inflate(R.layout.grid_layout,null);
        ImageView imageView=  view.findViewById(R.id.imageView);
        final String imgUrl=view.getResources().getString(R.string.image_url);
//        String imgString = view.getResources().getString(R.string.image_url);
        Picasso.get().load(imgUrl+resultLists.get(i).getPoster_path()).into(imageView);
       // Log.e("image_url",R.string.image_url+resultLists.get(i).getPoster_path());
       /* SharedPreferences.Editor sharedPref=context.getSharedPreferences("MovieDetail",Context.MODE_PRIVATE).edit();
        sharedPref.putString("title", resultLists.get(i).getTitle());
        sharedPref.apply();*/
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(context,MovieDetailActivity.class);
                intent.putExtra("title", resultLists.get(i).getTitle());
                intent.putExtra("overview", resultLists.get(i).getOverview());
                intent.putExtra("releaseDate", resultLists.get(i).getRelease_date());
                intent.putExtra("vote", resultLists.get(i).getVote_average());
                intent.putExtra("poster", imgUrl+resultLists.get(i).getPoster_path());

                context.startActivity(intent);
            }
        });


        return view;
    }
}
