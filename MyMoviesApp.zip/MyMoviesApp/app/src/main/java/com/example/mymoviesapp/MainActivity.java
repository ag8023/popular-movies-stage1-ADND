package com.example.mymoviesapp;
//Step 1 and 6
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.GridView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    GridView gridView; // to present the results in a grid pattern
    List<ResultList> responseJSONList=new ArrayList<>(); // to collect data from the JSON API call

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        gridView=findViewById(R.id.gridView);

         MovieList(); // Retrofit usage inside this method
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater=getMenuInflater();
       inflater.inflate(R.menu.menu_main,menu);
       return true;
    }


    @Override
    public boolean onOptionsItemSelected( MenuItem item) {
        int id=item.getItemId();
        switch(id) {
            case R.id.sortbypopularity:
                MovieList();
//                Intent intent= new Intent(Intent.ACTION_SEND);
//                intent.setType("text/plain");
//                intent.putExtra(Intent.EXTRA_EMAIL, "aasavari@gmail.com");
//                intent.putExtra(Intent.EXTRA_SUBJECT,"hsbh");
//                intent.putExtra(Intent.EXTRA_TEXT,"bsc");
//                startActivity(Intent.createChooser(intent,"share"));
//                Toast.makeText(MainActivity.this, "Sort by Popularity", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.sortbyrating:
                TopRatedMovies();
                //Toast.makeText(MainActivity.this, "Sort by Rating", Toast.LENGTH_SHORT).show();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
    public void MovieList(){
        try {
            final ProgressDialog progressDialog= new ProgressDialog(MainActivity.this);
            progressDialog.show();
            ApiInterface apiInterface=RerofitClientInstance.getApiCLient();
            apiInterface.getPopular("insert your api key here").enqueue(new Callback<ResponseJSON>() {
                @Override
                public void onResponse(Call<ResponseJSON> call, Response<ResponseJSON> response) {
                    if(response.body()!=null){
                        responseJSONList=response.body().getResultList();
                        GridAdapter gridAdapter=new GridAdapter(MainActivity.this,responseJSONList);
                        gridView.setAdapter(gridAdapter);
                    }
progressDialog.dismiss();
                }

                @Override
                public void onFailure(Call<ResponseJSON> call, Throwable t) {

        }
    });

        }catch (Exception e){

        }

    }

    public void TopRatedMovies(){
        try {
            final ProgressDialog progressDialog= new ProgressDialog(MainActivity.this); // to load data
            progressDialog.show();
            ApiInterface apiInterface=RerofitClientInstance.getApiCLient(); // instantiate
            apiInterface.getToprated("insert your api key here").enqueue(new Callback<ResponseJSON>() { //insert your api key as a string parameter to getToprated()
                @Override
                public void onResponse(Call<ResponseJSON> call, Response<ResponseJSON> response) {
                    if(response.body()!=null){
                        responseJSONList=response.body().getResultList();
                        GridAdapter gridAdapter=new GridAdapter(MainActivity.this,responseJSONList);
                        gridView.setAdapter(gridAdapter);
                    }
                    progressDialog.dismiss();
                }

                @Override
                public void onFailure(Call<ResponseJSON> call, Throwable t) {

                }
            });

        }catch (Exception e){

        }

    }



}
